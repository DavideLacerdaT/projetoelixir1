unicode_util_compat
=====


allows the usage of unicode_util and string from Erlang R21 in older erlang >= R18.

Build
-----

    $ rebar3 compile
